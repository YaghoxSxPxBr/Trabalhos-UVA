package AV1;


public class AV1 {
    

    public static void main(String[] args) {
        
        Computador computador1 = new Computador("Ti2000",2000,8,2,250);
        Computador computador2 = new Computador("Gx8000",7500,32,6,1000);
        Computador computador3 = new Computador();
        Computador computador4 = new Computador();
        
    
        computador1.Imprimir();
        computador2.Imprimir();
        computador3.Imprimir();
        computador4.Imprimir();
        

    }

}
