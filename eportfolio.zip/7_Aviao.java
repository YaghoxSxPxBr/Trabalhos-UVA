package AV1;

import java.util.Scanner;

public class Aviao extends Viagem {

  private String prefixo, revisao;

        public String getPrefixo() {
        return prefixo;
    }

    public void setPrefixo(String pre) {
        if (!pre.isEmpty()) {
            prefixo = pre;
        } else {
            System.out.println("valor inválido, não foi atribuído");
        }
    }

    public String getRevisao() {
        return revisao;
    }

    public void setRevisao(String re) {
        if (!re.isEmpty()) {
            revisao = re;
        } else {
            System.out.println("valor inválido, não foi atribuído");
        }
    }
    public Aviao() {super();}
    
    public Aviao(String prefixo, String revisao, int npassageiros,float valor, float combustivel) 
    {super(valor,combustivel,npassageiros);
        this.prefixo = "A22";
        this.revisao = "20 de 06 de 2025";
        this.valor = 50.5f;
        this.combustivel = 58.6f;
        this.npassageiros = 82;
    }
  
    public Aviao(float valor) {
       this.valor = valor;
    }

    public Aviao(int npassageiros) {
        this.npassageiros = npassageiros;
    }

    public Aviao(float valor, float combustivel) {
        this.valor = valor;
        this.combustivel = combustivel;
    }

    public Aviao(float valor, float combustivel, int npassageiros) {
        this.valor = valor;
        this.combustivel = combustivel;
        this.npassageiros = npassageiros;
    }
 public void cadastrar(String prefixo, String revisao, int npassageiros,float valor, float combustivel) 
    {super(valor,combustivel,npassageiros);
        this.prefixo = prefixo;
        this.revisao = revisao;
    
}
  @Override
    public void entrada() {
// Como o Scanner não é um atributo da classe,
// ele deve ser declarado dentro do método em que será utilizado,
// como um objeto auxiliar
        Scanner sc = new Scanner(System.in);
        super.entrada();
        System.out.println("Prefixo do aviao: ");
        setPrefixo(sc.nextLine());
        System.out.println("Data da revisao: ");
        setRevisao(sc.nextLine());
    }

  @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Prefixo do aviao:" + getPrefixo());
        System.out.println("Data da revisao: " + getRevisao());
    }

}
