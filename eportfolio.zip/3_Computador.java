package AV1;
public class Computador {
    public String modelo;
    public int valor;
    public int memoria;
    public int fans;
    public int hd;

 public Computador(){
        this.modelo="A2000";
        this.valor=3500;
        this.memoria=16;
        this.fans=4;
        this.hd=500;
}
public Computador(String modelo,int valor, int memoria, int fans, int hd){
        this.modelo=modelo;
        this.valor=valor;
        this.memoria=memoria;
        this.fans=fans;
        this.hd=hd;
}
   public String getModelo(){
    return modelo;
    }
    public int getValor(){
    return valor;
    }
    public int getMemoria(){
    return memoria;
    }
    public int getFans(){
    return fans;
    }
    public int getHd(){
    return hd;
    }
    



       public void setModelo(String m){
           if(!m.isEmpty()) {
              modelo = m;
             }
                else {
                System.out.println("valor inválido, não foi atribuído");
                }
             }
    public void setValor(int v){
       if(v>=0){
          valor=v;
      }
           else {
                System.out.println("valor inválido, não foi atribuído");
                }
             }
    public void setMemoria(int ram){
         if(ram==2 || ram==4 || ram==8 || ram==16 || ram==32){
           memoria = ram;
   }
                else {
                System.out.println("valor inválido, não foi atribuído");
                }
             }
    public void setFans(int n){
        if(n>=0){
         fans=n;
      }
           else {
                System.out.println("valor inválido, não foi atribuído");
                }
            
    }
    public void setGbHd(int h){
       if(h==250|| h==500 ||h==1000){
         hd=h;
      }
           else {
                System.out.println("valor inválido, não foi atribuído");
    }
    }


    
    
    
    public void Imprimir() {
        System.out.println("Modelo do computador " + modelo);
        System.out.println("Valor do computador R$" + valor);
        System.out.println("Quantidade de memoria do computador " + memoria+"gbs de ram");
        System.out.println("Quantas fans vem no gabinete do computador " + fans);
        System.out.println("Quanto de espaco no hd " + hd +"gbs");
        System.out.println("");
        System.out.println("");
    }
}