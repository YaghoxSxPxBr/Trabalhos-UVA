package AV1;

public class appViagem {

    public static void main(String[] args) {
        Aviao vetAviao[] = new Aviao[10];

        for (int i = 0; i < vetAviao.length; i++) {
            vetAviao[i] = new Aviao();
            System.out.println("Prencha os dados de " +(i+1)+ "Aviao");
            vetAviao[i].entrada();
            System.out.println("lista dos dados de " +(i+1)+ "Aviao");
            vetAviao[i].imprimir();
        }
        
        
     Barco vetBarco[] = new Barco[10];
        for (int i = 0; i < vetBarco.length; i++) {
            vetBarco[i] = new Barco();
            System.out.println("Prencha os dados de " +(i+1)+ "Navio");
            vetBarco[i].entrada();
            System.out.println("lista dos dados de " +(i+1)+ "Navio");
            vetBarco[i].imprimir();
        }
}
}