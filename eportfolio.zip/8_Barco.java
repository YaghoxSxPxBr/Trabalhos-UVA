package AV1;

import java.util.Scanner;

public class Barco extends Viagem {

    private String nome, datalc;
    private int ntripulantes;

    public String getNome() {
        return nome;
    }

    public void setNome(String n) {
        if (!n.isEmpty()) {
            nome = n;
        } else {
            System.out.println("valor inválido, não foi atribuído");
        }
    }

    public String getDatalc() {
        return datalc;
    }

    public void setDatalc(String dlc) {
        if (!dlc.isEmpty()) {
            datalc = dlc;
        } else {
            System.out.println("valor inválido, não foi atribuído");
        }
    }

    public int getNtripulantes() {
        return ntripulantes;
    }

    public void setNtripulantes(int NT) {
        if (NT >= 0 && NT <=npassageiros) {
            ntripulantes = NT;
        } else {
            System.out.println("valor inválido, não foi atribuído");
        }

    }

    public Barco() {
        super();
    }

    public Barco(String nome, String datalc, int ntripulantes, int npassageiros, float valor, float combustivel) {
        super(valor, combustivel, npassageiros);
        this.nome = "SS.BATATA";
        this.datalc = "20 de 08 de 2028";
        this.ntripulantes = 20;
        this.valor = 35.7f;
        this.combustivel = 45.8f;
        this.npassageiros = 75;
    }

    public Barco(float valor) {
        this.valor = valor;
    }
    
    public Barco(int npassageiros) {
        this.npassageiros = npassageiros;
    }

    public Barco(float valor, float combustivel) {
        this.valor = valor;
        this.combustivel = combustivel;
    }

    public Barco(float valor, float combustivel, int npassageiros) {
        this.valor = valor;
        this.combustivel = combustivel;
        this.npassageiros = npassageiros;
    }
    
        public void cadastrar(String nome, String datalc, int ntripulantes, int npassageiros, float valor, float combustivel) {
        super(valor, combustivel, npassageiros);
        setNome(nome);
        setDatalc(datalc);
        setNtripulantes(ntripulantes);
        
    }

    @Override
    public void entrada() {
// Como o Scanner não é um atributo da classe,
// ele deve ser declarado dentro do método em que será utilizado,
// como um objeto auxiliar
        Scanner sc = new Scanner(System.in);
        super.entrada();
        System.out.println("Digite o Nome: ");
        setNome(sc.nextLine());
        System.out.println("Digite a daata de Lancameto: ");
        setDatalc(sc.nextLine());
        System.out.println("Numero de tripulantes do navio: ");
        setNtripulantes(Integer.parseInt(sc.nextLine()));

    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Nome: " + getNome());
        System.out.println("Data de Lancameto: " + getValor());
        System.out.println("Numero de tripulantes do navio: " + getNtripulantes());
    }
}
