package AV1;

import java.util.Scanner;

public class Viagem {
// Atributos

    public int npassageiros;
    public float valor, combustivel;

    public float getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(float c) {
        if (c >= 0) {
            combustivel = c;
        } else {
            System.out.println("valor inválido, não foi atribuído");
        }
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float v) {
        if (v >= 0) {
            valor = v;
        } else {
            System.out.println("valor inválido, não foi atribuído");
        }
    }

    public int getNpassageiros() {
        return npassageiros;
    }

    public void setNpassageiros(int NP) {
        if (NP >= 0) {
            npassageiros = NP;
        } else {
            System.out.println("valor inválido, não foi atribuído");
        }
    }

    public Viagem() {
    }

    public Viagem(float valor) {
       this.valor = valor;
    }

    public Viagem(int npassageiros) {
        this.npassageiros = npassageiros;
    }

    public Viagem(float valor, float combustivel) {
        this.valor = valor;
        this.combustivel = combustivel;
    }

    public Viagem(float valor, float combustivel, int npassageiros) {
        this.valor = valor;
        this.combustivel = combustivel;
        this.npassageiros = npassageiros;
    }
    
public void cadastrar(float valor, float combustivel, int npassageiros) {
        this.valor = valor;
        this.combustivel = combustivel;
        this.npassageiros = npassageiros;
}
    public void entrada() {
// Como o Scanner não é um atributo da classe,
// ele deve ser declarado dentro do método em que será utilizado,
// como um objeto auxiliar
        Scanner sc = new Scanner(System.in);
        System.out.println("digite a Capacidade do tanque de Combustivel: ");
        setCombustivel(Float.parseFloat(sc.nextLine()));
        System.out.println("Valor da viagem: ");
        setValor(Float.parseFloat(sc.nextLine()));
        System.out.println("Numero de passageiros fazendo a viagem: ");
        setNpassageiros(Integer.parseInt(sc.nextLine()));

    }

    public void imprimir() {
        System.out.println("------------------------------------------------------------------");
        System.out.println("Capacidade do tanque de Combustivel:" + getCombustivel());
        System.out.println("Valor da viagem: " + getValor());
        System.out.println("Numero de passageiros fazendo a viagem: " + getNpassageiros());
    }
}
